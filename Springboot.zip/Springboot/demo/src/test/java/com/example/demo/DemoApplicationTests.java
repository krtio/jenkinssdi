package com.example.demo;

import com.example.demo.User;
import com.example.demo.UserDao;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class DemoApplicationTests { // 여기서 data 잘 들어가나 test 할 수 있음

	@Autowired
	private UserDao userDao;

	@Test
	void addUserTest() {
		User user = new User();
		user.setId("unique_id"); // id 필드에 값 설정
		user.setPassword("987456");
		user.setName("라랄라");
		user.setAge(1);

		userDao.save(user);
	}


	@Test
	void getAllUsersAndDeleteThem() {
		List<User> users = userDao.getAllUsers();
		for (User user : users) {
			userDao.delete(user); // 다 지움
		}
	}
}
